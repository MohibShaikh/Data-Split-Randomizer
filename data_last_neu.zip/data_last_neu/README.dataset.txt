# gg > 2024-08-23 8:16pm
https://universe.roboflow.com/industryproj/gg-sncrj

Provided by a Roboflow user
License: CC BY 4.0

